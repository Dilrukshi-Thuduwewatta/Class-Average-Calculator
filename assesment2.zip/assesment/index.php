

<!DOCTYPE html>
<html>
<head>

<style>

body{
	
	 background-image: url('uni.jpg');
	  background-repeat: no-repeat;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}

</style>

<title>Import file in csv</title>
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>









<div class="topnav">
  <a class="active" href="login.html">LOGING</a>
  <a href="db.php">DATABASE</a>

</div>







<div class="container">
	<div class="cols-md-6">
		<form action="code.php" method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label for="file">Select the excel file</label>
				<input type="file" name="file" class="form-control"  accept=".xls,.xlsx">
			</div>
			<div>
				<button type="submit" name="import" class="btn btn-primary">Import</button>
			</div>
		</form>
	</div>
	
</div>
</body>
</html>

