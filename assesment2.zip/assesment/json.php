<?php

$con=mysqli_query("localhost","root","","test");


if(!$con){
	
	echo "could not connected";
}

?>