<?php

$con=mysqli_connect("localhost","root","","test");


if(!$con){
	
	echo "could not connected";
}


$q="select * from student";
$result=mysqli_query($con,$q);

$rows=array();
while($row=mysqli_fetch_assoc($result)){
	
	$rows[]=$row;
	
}


echo json_encode($rows);



?>